:- dynamic
self/2,
queueSize/1,
friendly/6,
isMorphing/2,
minerals/1,
unitAmount/2,
gas/1,
supply/2,
train/1,
queue/1.