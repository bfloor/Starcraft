:- dynamic
friendly/4,
self/2,
unitAmount/2,
minerals/1,
gas/1,
phase/1. %integer to identify if game is in construction phase or war phase